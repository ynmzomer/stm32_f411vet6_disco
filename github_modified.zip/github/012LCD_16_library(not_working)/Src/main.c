/*
 * Project: 012LCD_16_library(not_working)
 * Description: Basic STM32 project demonstrating fundamental concepts.
 * Author: Betül Atalay
 */

#include <stdint.h>
#include "main.h"

void lcd_init(void);
void lcd_gpio_init(void);
void lcd_send_data(uint8_t data);
void lcd_send_command(uint8_t command);
void delay_us(uint32_t us);
void delay_ms(uint32_t ms);

int main(void)
{
    lcd_gpio_init();  // GPIO'ları başlat
    lcd_init();       // LCD başlat

    lcd_send_command(0x80); // LCD'nin ilk satırının başına git
    lcd_send_data('A');     // LCD'ye 'A' harfi yazdır

    while (1);
}

/**
 * @brief LCD Başlatma Fonksiyonu
 */
void lcd_init(void) {
    delay_ms(50);  // LCD güç stabilizasyonu için bekleme süresi

    lcd_send_command(0x38); // 8-bit mod, 2 satır, 5x8 font
    delay_ms(50);

    lcd_send_command(0x0C); // Ekran açık, imleç kapalı
    delay_ms(50);

    lcd_send_command(0x01); // Ekranı temizle
    delay_ms(50);

    lcd_send_command(0x06); // İmleç sağa ilerler
    delay_ms(50);
}

/**
 * @brief GPIO Pinlerini Yapılandırma
 */
void lcd_gpio_init(void) {
    // AHB1 Clock Enable
    RCC_AHB1ENR_t volatile *const pRCC = (RCC_AHB1ENR_t *)(RCC_BASE_ADRESS + RCC_AHB1ENR_OF);
    pRCC->gpioa_en = 1;
    pRCC->gpiod_en = 1;

    // GPIOA ve GPIOD'u çıkış moduna al
    GPIOx_MODER_t volatile *const pAmoder = (GPIOx_MODER_t *)(GPIOA_BASE_ADRESS);
    GPIOx_MODER_t volatile *const pDmoder = (GPIOx_MODER_t *)(GPIOD_BASE_ADRESS);

    pDmoder->pin_8  = 1; // RS
    pDmoder->pin_9  = 1; // RW
    pDmoder->pin_10 = 1; // EN

    // LCD veri yolu (DB0 - DB7)
    pAmoder->pin_0 = 1;
    pAmoder->pin_1 = 1;
    pAmoder->pin_2 = 1;
    pAmoder->pin_3 = 1;
    pAmoder->pin_4 = 1;
    pAmoder->pin_5 = 1;
    pAmoder->pin_6 = 1;
    pAmoder->pin_7 = 1;
}

/**
 * @brief LCD'ye Komut Gönderme
 */
void lcd_send_command(uint8_t command) {
    GPIOx_ODR_t volatile *const pD_ODR = (GPIOx_ODR_t *)(GPIOD_BASE_ADRESS + GPIOx_ODR_OF);
    GPIOx_ODR_t volatile *const pA_ODR = (GPIOx_ODR_t *)(GPIOA_BASE_ADRESS + GPIOx_ODR_OF);

    pD_ODR->odr8 = 0; // RS = 0 (Komut)
    pD_ODR->odr9 = 0; // RW = 0 (Yazma)

    // Komutu DB0 - DB7'ye yaz
    *((volatile uint8_t*)pA_ODR) = command;

    // Enable sinyalini daha uzun tut
    pD_ODR->odr10 = 1;
    delay_us(200);  // Daha uzun bekleme süresi
    pD_ODR->odr10 = 0;
    delay_ms(2);
}

/**
 * @brief LCD'ye Veri Gönderme (Tek Karakter)
 */
void lcd_send_data(uint8_t data) {
    GPIOx_ODR_t volatile *const pD_ODR = (GPIOx_ODR_t *)(GPIOD_BASE_ADRESS + GPIOx_ODR_OF);
    GPIOx_ODR_t volatile *const pA_ODR = (GPIOx_ODR_t *)(GPIOA_BASE_ADRESS + GPIOx_ODR_OF);

    pD_ODR->odr8 = 1; // RS = 1 (Veri Modu)
    pD_ODR->odr9 = 0; // RW = 0 (Yazma Modu)

    // 'A' harfini DB0 - DB7'ye yaz
    *((volatile uint8_t*)pA_ODR) = data;

    // Enable sinyalini uzun süre tut
    pD_ODR->odr10 = 1;
    delay_us(200);  // Daha uzun bekleme süresi
    pD_ODR->odr10 = 0;
    delay_ms(2);
}

/**
 * @brief Mikro Saniye Gecikme
 */
void delay_us(uint32_t us) {
    for (uint32_t i = 0; i < 4 * us; i++);
}

/**
 * @brief Mili Saniye Gecikme
 */
void delay_ms(uint32_t ms) {
    for (uint32_t i = 0; i < 4000 * ms; i++);
}
