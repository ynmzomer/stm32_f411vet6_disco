/*
 * main.h
 *
 *  Created on: Jan 25, 2025
 *      Author: omery
 */

#ifndef MAIN_H_
#define MAIN_H_

#define RCC_BASE_ADRESS (0x40023800UL)
#define GPIOA_BASE_ADRESS (0x40020000UL)
#define GPIOD_BASE_ADRESS (0x40020C00UL)
#define RCC_AHB1ENR_OF (0x30ul)
#define GPIOx_ODR_OF (0x14ul)

typedef struct{
	uint32_t gpioa_en 	: 1 ;
	uint32_t gpiob_en 	: 1 ;
	uint32_t gpioc_en 	: 1 ;
	uint32_t gpiod_en 	: 1 ;
	uint32_t gpioe_en 	: 1 ;
	uint32_t reserved_1 : 2 ;
	uint32_t gpioh_en 	: 1 ;
	uint32_t reserved_2 : 4 ;
	uint32_t crc_en 	: 1 ;
	uint32_t reserved_3 : 3 ;
	uint32_t reserved_4 : 5 ;
	uint32_t DMA1_en 	: 1 ;
	uint32_t DMA2_en 	: 1 ;
	uint32_t reserved_5 : 9 ;

}RCC_AHB1ENR_t;

typedef struct{
	uint32_t pin_0  :2 ;
	uint32_t pin_1 	:2 ;
	uint32_t pin_2 	:2 ;
	uint32_t pin_3 	:2 ;
	uint32_t pin_4 	:2 ;
	uint32_t pin_5 	:2 ;
	uint32_t pin_6 	:2 ;
	uint32_t pin_7 	:2 ;
	uint32_t pin_8 	:2 ;
	uint32_t pin_9 	:2 ;
	uint32_t pin_10	:2 ;
	uint32_t pin_11	:2 ;
	uint32_t pin_12 :2 ;
	uint32_t pin_13 :2 ;
	uint32_t pin_14 :2 ;
	uint32_t pin_15 :2 ;


}GPIOx_MODER_t ;

typedef struct{
	uint32_t pin_0  :2 ;
	uint32_t pin_1 	:2 ;
	uint32_t pin_2 	:2 ;
	uint32_t pin_3 	:2 ;
	uint32_t pin_4 	:2 ;
	uint32_t pin_5 	:2 ;
	uint32_t pin_6 	:2 ;
	uint32_t pin_7 	:2 ;
	uint32_t pin_8 	:2 ;
	uint32_t pin_9 	:2 ;
	uint32_t pin_10	:2 ;
	uint32_t pin_11	:2 ;
	uint32_t pin_12 :2 ;
	uint32_t pin_13 :2 ;
	uint32_t pin_14 :2 ;
	uint32_t pin_15 :2 ;


}GPIOx_OSPEEDR_t;

typedef struct{

	uint32_t odr0 : 1 ;
	uint32_t odr1 : 1 ;
	uint32_t odr2 : 1 ;
	uint32_t odr3 : 1 ;
	uint32_t odr4 : 1 ;
	uint32_t odr5 : 1 ;
	uint32_t odr6 : 1 ;
	uint32_t odr7 : 1 ;
	uint32_t odr8 : 1 ;
	uint32_t odr9 : 1 ;
	uint32_t odr10 : 1 ;
	uint32_t odr11 : 1 ;
	uint32_t odr12 : 1 ;
	uint32_t odr13 : 1 ;
	uint32_t odr14 : 1 ;
	uint32_t odr15 : 1 ;

}GPIOx_ODR_t;





#endif /* MAIN_H_ */
